-- AlterTable
ALTER TABLE "Lesson" ADD COLUMN     "difficulty" TEXT,
ADD COLUMN     "objectives" TEXT;
